function [RMSE]=PSO_Model_of_NMC_multi(par_op,current,voltage,len_cur)
U_terminal=zeros(size(voltage));
 for i=1:length(len_cur)
    startpoint=sum(len_cur(1:i-1));
    current_tmp=current(startpoint:startpoint+len_cur(i)-1);
    [U_terminal_tmp,~]=Model_of_NMC(par_op_tmp,current_tmp);
    U_terminal(startpoint:startpoint+len_cur(i)-1)=U_terminal_tmp;
 end
 error=U_terminal-voltage;
 RMSE=rms(error);
end

