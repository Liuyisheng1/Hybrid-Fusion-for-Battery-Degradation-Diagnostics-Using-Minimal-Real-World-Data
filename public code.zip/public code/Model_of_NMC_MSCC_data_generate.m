function [MSCC_current,MSCC_U_terminal]=Model_of_NMC_MSCC_data_generate(para_op_input)
% We utilize this function to generate MSCC data for different combinations of parameters,
% and here we simply provide an example to show the steps of our simulated data generation.
% In this example, the constrained current iterative solution method is applied to common CC-CV charging data.
for ca=1:3
    switch ca
        case 1
            ub_c=0.75;
            cur=3.2;
        case 2
            ub_c=1.25;
            cur=3.2*1.5;
        case 3
            ub_c=1.75;
            cur=3.2*2;
    end
    for ind_plot=1:length(data_NCM_C_Si(ca).cycles)
        current=data_NCM_C_Si(ca).cycles(ind_plot).I;
        voltage=data_NCM_C_Si(ca).cycles(ind_plot).V;
        clear fixcurrent_CV_mex
        current_est=cur*ones(7000,1);
        para_op=para_op_cell{ca,ind_plot};
        [U_est,~]=Model_of_NMC(para_op,current_est); %electrochemistry model
        index_CV=find(U_est>4.2,1,'first')-1;
        leng=floor((7000-index_CV)/10);
        UB=linspace(ub_c,0,leng)/10;
        LB=zeros(1,leng);
        a=[diag(-1*ones(leng-1,1)),zeros(leng-1,1)];
        b=[zeros(leng-1,1),diag(1*ones(leng-1,1))];
        A = a+b;
        b = zeros(leng-1,1); %Constructive constraints
        if length(V_C_initial)>=length(UB)
            x0=V_C_initial(1:length(UB));
        else
            x0=LB;
            x0(1:length(V_C_initial))=V_C_initial;
        end
        options = optimoptions('fmincon','Display','none','Algorithm','sqp','MaxFunctionEvaluations',2e4,'StepTolerance',1e-50,'UseParallel',true,"OutputFcn",@outfun);
        clear fixcurrent_CV_mex
        codegen -config:mex fixcurrent_CV -args {x0,current_est,index_CV,para_op} -report;
        [V_C,error_rmse]=fmincon(@(V_current_CV)fixcurrent_CV_out(V_current_CV,current_est,index_CV,para_op),x0,A,b,[],[],LB,UB,[],options);
        V_C_initial=V_C;
        for i=1:length(V_C)
            current_est(index_CV+(i-1)*10+1:index_CV+(i)*10)=current_est(index_CV+(i-1)*10)-V_C(i);
        end
        current_est(index_CV+(length(V_C))*10+1:end)=0;
        ind=find(current_est<=0.16);
        current_est(ind)=0;
        current_est_struct_multi_real_data(ca).cycles(ind_plot).current=current_est;
        current_est_struct_multi_real_data(ca).cycles(ind_plot).errorrmse=error_rmse;
        ind_plot
        error_rmse
    end
end
end
