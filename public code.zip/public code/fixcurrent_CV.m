function RMSE=fixcurrent_CV(V_current_CV,current_est,index_CV,para_op)
    for i=1:length(V_current_CV)
        current_est(index_CV+(i-1)*10+1:index_CV+(i)*10)=current_est(index_CV+(i-1)*10)-V_current_CV(i);
    end
    current_est(index_CV+(length(V_current_CV))*10+1:end)=0;
    ind=find(current_est<=0);
    current_est(ind)=0;
    [U_est,~]=Model_of_NMC(para_op,current_est);
    target_voltage=4.2*ones(length(U_est(index_CV+1:end)),1);
    RMSE=rms(U_est(index_CV+1:end)-target_voltage);
end