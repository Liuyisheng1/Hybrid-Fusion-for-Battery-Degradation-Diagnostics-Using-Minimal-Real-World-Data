function RMSE=fixcurrent_CV_out(V_current_CV,current_est,index_CV,para_op)
    RMSE=fixcurrent_CV(V_current_CV,current_est,index_CV,para_op);
end